global smic plafond_seul aah_taux_plein mva;

% Chiffres de l'ann�e 2015
smic = 1457.52 ;%1445.38;
smicnet = 1135.99;
aah_taux_plein = 800.45; %790.18;
plafond_seul = 12*aah_taux_plein;
mva = 104.77;


aah_mva = aah_taux_plein+mva;
salaire_max = 2000;

abs_salaires = 0:0.1:salaire_max;
ord_ressources_tot = zeros(1,length(abs_salaires));
abs_salaires_impots = zeros(1,length(abs_salaires));

for i=1:length(ord_ressources_tot)
    abs_salaires_impots(i) = abs_salaires(i)-imposition(abs_salaires(i));
    ord_ressources_tot(i) = abattements_seul(abs_salaires(i))+abs_salaires_impots(i);
end

salaire_critique_min = mva/0.8;
salaire_inflexion_min = smic*0.3;
salaire_inflexion_max = (plafond_seul+0.4*(smic*0.3*12))/(12*0.6);
ressource_critique_min = abattements_seul(salaire_critique_min)+salaire_critique_min;
ressource_inflexion_min = abattements_seul(salaire_inflexion_min)+salaire_inflexion_min;
ressource_inflexion_max = abattements_seul(salaire_inflexion_max)+salaire_inflexion_max;

figure1 = figure('Color',[1 1 1]);
hold on;
area(abs_salaires,ord_ressources_tot,'Facecolor',[231 108 86]/255);
area(abs_salaires,abs_salaires_impots,'Facecolor',[194 222 242]/255);
plot(abs_salaires,ord_ressources_tot,'Color','r','LineWidth',2);
plot(abs_salaires,abs_salaires_impots,'Color','b','LineWidth',2);
plot([0 salaire_max],[0 salaire_max],'Color',[0 0 1],'LineWidth',1);
plot([0 salaire_max],[aah_mva aah_mva],'Color',[1 215 96]/255,'LineWidth',2);
plot([salaire_critique_min salaire_critique_min],[0 ressource_critique_min],'Color',[1 215 96]/255,'LineWidth',1,'Linestyle','--');
plot([salaire_inflexion_min salaire_inflexion_min],[0 ressource_inflexion_min],'--r');
plot([0 salaire_inflexion_min],[ressource_inflexion_min ressource_inflexion_min],'--r');
plot([salaire_inflexion_max salaire_inflexion_max],[0 ressource_inflexion_max],'--r');
plot([0 salaire_inflexion_max],[ressource_inflexion_max ressource_inflexion_max],'--r');


% Create xlabel
xlabel({'Salaire net imposable (en euros)'},'FontSize',12);

% Create ylabel
ylabel({'Ressources totales per�ues (en euros)'},'FontSize',12);

%title(char('Part des revenus d''activit� et de l''AAH diff�rentielle dans les ressources','d''une personne handicap�e isol�e qui b�n�ficie d''un emploi'));


% Create textbox
annotation(figure1,'textbox',...
    [0.324214285714285 0.500000000000001 0.306142857142857 0.0761904761904777],...
    'String',{'AAH vers�e'},...
    'FontWeight','bold',...
    'FontSize',18,...
    'FitBoxToText','off',...
    'LineStyle','none',...
    'Color',[1 0 0]);

% Create textbox
annotation(figure1,'textbox',...
    [0.3875 0.264285714285715 0.457142857142857 0.064285714285715],...
    'String',{'Salaire net apr�s imp�t'},...
    'FontWeight','bold',...
    'FontSize',18,...
    'FitBoxToText','off',...
    'LineStyle','none',...
    'Color',[0 0 1]);

% Create textbox
annotation(figure1,'textbox',...
    [0.582142857142857 0.492857142857144 0.45 0.0452380952380967],...
    'String',{'AAH taux plein + MVA'},...
    'FontWeight','bold',...
    'FontSize',18,...
    'FitBoxToText','off',...
    'LineStyle','none',...
    'Color',[0 0.8 0.2]);

% Create textbox
annotation(figure1,'textbox',...
    [0.201785714285714 0.873809523809526 0.608928571428571 0.0904761904761935],...
    'String',{'Part des revenus d''activit� et de l''AAH diff�rentielle dans les','ressources d''une personne handicap�e isol�e qui travaille'},...
    'FontSize',12,...
    'FitBoxToText','off',...
    'BackgroundColor',[1 0.694117647058824 0.392156862745098]);
