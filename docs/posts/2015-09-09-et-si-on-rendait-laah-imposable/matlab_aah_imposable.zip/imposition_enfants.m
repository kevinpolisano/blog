function mon_impot = imposition_enfants(salaire_net_imposable,invalide,NbEnfants)

global plafondC;

if nargin < 2
    invalide = 1;
    NbEnfants = 0;
end

if nargin == 2
    NbEnfants = 0;
end


% Annualisation du salaire net imposable
revenus_declares = 12*salaire_net_imposable;

% Chiffres 2015
nombre_parts = 1 + 0.5*invalide; % une demi part suppl�mentaire si invalide
if NbEnfants < 3
    nombre_parts = nombre_parts + 0.5*NbEnfants;
else
    nombre_parts = nombre_parts + 1 + NbEnfants;
end
abattement_fiscal_min = 426;     % abattement frais professionnel minimal
abattement_fiscal_max = 12157;   % et maximal, sinon -10 %
revenu_special_min = 14710;      % fourchettes pour lesquelles est appliqu�
revenu_special_max = 23700;      % un abattement sp�cial d'invalidit�
if invalide
    abattement_special_max = 2344; % abattement sp�cial pour faible salaire
    abattement_special_min = 1172; % abattement sp�cial pour salaire moyen
else
    abattement_special_min = 0;
    abattement_special_max = 0;
end
tranche1 = 9690;  taux1 = 0;     % Les diff�rentes tranches d'imposition
tranche2 = 26764; taux2 = 0.14;
tranche3 = 71754; taux3 = 0.3;
tranche4 = 151956;taux4 = 0.41;
impot_min = 1135;

% Abattement fiscal de 10% de frais professionnels
abattement_fiscal = min(max(abattement_fiscal_min,0.1*revenus_declares),abattement_fiscal_max);
revenus_net_global = max(revenus_declares-abattement_fiscal,0);

% D�termination de l'abattement sp�cial li� � l'invalidit�
if (revenus_net_global <= revenu_special_min) && (invalide)
    abattement_special = abattement_special_max;
elseif (revenus_net_global > revenu_special_min) && (revenus_net_global < revenu_special_max) && (invalide)
    abattement_special = abattement_special_min;
else
    abattement_special = 0;
end

% Application de l'abattement sp�cial li� � l'invalidit�
revenus_net_imposable = max(revenus_net_global-abattement_special,0);

% Calcul du quotient familial
quotient_familial = max(revenus_net_imposable/nombre_parts,0.1);

% On stocke les tranches d'imposition et leur taux dans des tableaux
tranches = zeros(4,1);     taux = zeros(3,1);
tranches(1) = 0;
tranches(2) = tranche1;    taux(1) = taux1;
tranches(3) = tranche2;    taux(2) = taux2;
tranches(4) = tranche3;    taux(3) = taux3;
tranches(5) = tranche4;    taux(4) = taux4;

% D�termination de la tranche marginal d'imposition (TMI)
i0 = 1;
while tranches(i0) < quotient_familial
    i0 = i0+1;
end
i0 = i0-1;

% Calcul de l'imp�t brut
sum = 0;
for i=2:i0
    sum = sum + (tranches(i)-tranches(i-1))*taux(i-1);
end
impot_brut = sum + (quotient_familial-tranches(i0))*taux(i0);
impot_brut = impot_brut*nombre_parts;

reduction = 0;
% Plafonnement du quotient familial
if invalide
    temp = 12*imposition(salaire_net_imposable,0); % comparaison avec
    A = impot_brut;                                % QF d'une seule part
    B = temp-1508; % art. 197 code des imp�ts
    if A < B
        % disp('plafonnement bas 1508')
        impot_brut = B;
        reduction = B-A; 
        if reduction > 1504
            persistent compteur;
            if isempty(compteur)
                %disp(['Plafonnement haut 1508+1497 : ',num2str(salaire_net_imposable)]);
                plafondC = salaire_net_imposable;
            end
            compteur = 1;
            reduction = 1504; % art. 197 code des imp�ts
        end
    end
end

% Application de la decote
decote = 0;
if impot_brut < impot_min
    decote = impot_min-impot_brut;  % � changer depuis 2015 
end
impot_net = max(impot_brut-decote,0);

% R�duction d'impot compl�mentaire
impot_net = max(impot_net-reduction,0);

% Sortie imp�t mensualis�
mon_impot = impot_net/12;

if 0 % � mettre � 1 si on utilise la fonction imposition seule

disp(['Nombre de parts : ',num2str(nombre_parts)]);
disp(['Salaire net mensuel imposable : ',num2str(salaire_net_imposable)]);
disp(['Revenus net annuel global : ',num2str(12*salaire_net_imposable)]);
disp(['Revenu net imposable : ',num2str(max(revenus_net_global))]);
disp(['Abattements sp�ciaux : ',num2str(abattement_special)]);
disp(['Revenu net imposable apr�s abattements sp�ciaux : ',num2str(revenus_net_imposable)]);
disp(['Droits simples : ',num2str(impot_brut)]);
disp(['Decote : ',num2str(decote)]);
if reduction > 0
    disp(['Reduction impot compl�mentaire : ',num2str(reduction)]);
end
disp(['Impot sur le revenu net : ',num2str(impot_net)]);

end


end

