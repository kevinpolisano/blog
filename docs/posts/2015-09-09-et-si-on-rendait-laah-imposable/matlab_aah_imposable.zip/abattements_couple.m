% Calcul pour un b�n�ficiaire en couple, l'AAH vers�e en fonction
% du salaire mensuel net imposable du conjoint
function aah = abattements_couple(salaire)
global plafond_couple plafond_seul;
salaire_max = (plafond_couple)/(12*0.9*0.8);

if (salaire >= 0) && (salaire <= salaire_max)
    assiette = round(0.9*0.8*(salaire*12));
else
    assiette = plafond_couple;
end
aah = (plafond_couple-assiette)/12;
if (aah > plafond_seul/12)
    aah = plafond_seul/12;
end

end