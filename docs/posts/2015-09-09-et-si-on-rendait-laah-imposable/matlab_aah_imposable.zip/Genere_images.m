% Script qui g�n�re toutes les images � partir des diff�rents programmes

clear all; clc;

mkdir images_generees; % r�pertoire contenant les images

set(0,'DefaultFigureVisible','off'); % pour ne pas afficher les figures

AAHdifferentielle; % graphe de l'AAH en fonction du salaire du b�n�ficiaire

export_fig(figure1,'images_generees/AAH_differentielle_salaire.pdf');

close all;
clf;

AAH; % graphe de la cumulation du salaire avec l'AAH + imp�t (loupe)

export_fig(figure1,'images_generees/AAH_cumulation_salaire.pdf');

close all;
clf;

AAHcouple; % graphe de l'AAH vers�e en fonction du salaire du conjoint

export_fig(figure1,'images_generees/AAH_impact_conjoint.pdf');

close all;
clf;

% courbe 3D comparant les imp�ts du couple si mari� ou en concubinage
% commenter la variable type dans le fichier impots_mariage_vs_concubinage.m
type = 0; impots_mariage_vs_concubinage; 
export_fig(h1,'images_generees/Comparaison_impots_mariage_concubinage_valide_valide.tif','-r300');
export_fig(h2,'images_generees/Difference_impots_mariage_concubinage_valide_valide.tif','-r300');
export_fig(h3,'images_generees/Deavantage_fiscal_impots_mariage_concubinage_valide_valide.tif','-r300');
type = 1; impots_mariage_vs_concubinage; 
export_fig(h1,'images_generees/Comparaison_impots_mariage_concubinage_invalide_valide.tif','-r300');
export_fig(h2,'images_generees/Difference_impots_mariage_concubinage_invalide_valide.tif','-r300');
export_fig(h3,'images_generees/Deavantage_fiscal_impots_mariage_concubinage_invalide_valide.tif','-r300');
type = 2; impots_mariage_vs_concubinage; 
export_fig(h1,'images_generees/Comparaison_impots_mariage_concubinage_invalide_invalide.tif','-r300');
export_fig(h2,'images_generees/Difference_impots_mariage_concubinage_invalide_invalide.tif','-r300');
export_fig(h3,'images_generees/Deavantage_fiscal_impots_mariage_concubinage_invalide_invalide.tif','-r300');

close all; clf;

% comparaison avant/apr�s AAH imposable sur les imp�ts des mari�s
% commenter la variable type dans le fichier comparaison_mariage_AAH_imposable.m
type = 1; comparaison_mariage_AAH_imposable; 
export_fig(h1,'images_generees/Comparaison_impots_mariage_AAHimposable_invalide_valide.tif','-r300');
export_fig(h2,'images_generees/Difference_impots_mariage_AAHimposable_invalide_valide.tif','-r300');
export_fig(h3,'images_generees/Deavantage_fiscal_impots_mariage_AAHimposable_invalide_valide.tif','-r300');
type = 2; comparaison_mariage_AAH_imposable; 
export_fig(h1,'images_generees/Comparaison_impots_mariage_AAHimposable_invalide_invalide.tif','-r300');
export_fig(h2,'images_generees/Difference_impots_mariage_AAHimposable_invalide_invalide.tif','-r300');
export_fig(h3,'images_generees/Deavantage_fiscal_impots_mariage_AAHimposable_invalide_invalide.tif','-r300');

close all; clf;

% comparaison avant/apr�s AAH imposable sur les revenus r�els des mari�s 
% + courbe 3D de l'AAH couple habituelle
% commenter la variable type dans le fichier comparaison_revenus_mariage_AAH_imposable.m
type = 1; comparaison_revenus_mariage_AAH_imposable; 
export_fig(h1,'images_generees/Comparaison_revenus_mariage_AAHimposable_invalide_valide.tif','-r300');
export_fig(h2,'images_generees/Difference_revenus_mariage_AAHimposable_invalide_valide.tif','-r300');
export_fig(h3,'images_generees/AAH_couple_3D_invalide_valide.tif','-r300');
export_fig(h4,'images_generees/AAH_couple_2D_invalide_valide.tif','-r300');
type = 2; comparaison_revenus_mariage_AAH_imposable; 
export_fig(h1,'images_generees/Comparaison_revenus_mariage_AAHimposable_invalide_invalide.tif','-r300');
export_fig(h2,'images_generees/Difference_revenus_mariage_AAHimposable_invalide_invalide.tif','-r300');

close all; clf;

% comparaison avant/apr�s AAH imposable sur les revenus r�els des concubins
% + comparaison courbe 3D AAH seul et en couple
% commenter la variable type dans le fichier comparaison_revenus_concubinage_AAH_imposable.m
type = 1; comparaison_revenus_concubinage_AAH_imposable; 
export_fig(h1,'images_generees/Comparaison_revenus_concubinage_AAHimposable_invalide_valide.tif','-r300');
export_fig(h2,'images_generees/Comparaison_AAH_couple_vs_seul_3D.tif','-r300');
export_fig(h3,'images_generees/Difference_AAH_couple_vs_seul_3D.tif','-r300');
export_fig(h4,'images_generees/Difference_AAH_couple_vs_seul_2D.tif','-r300');
export_fig(h5,'images_generees/zone_demarcation.tif','-r300');
type = 2; comparaison_revenus_concubinage_AAH_imposable; 
export_fig(h1,'images_generees/Comparaison_revenus_concubinage_AAHimposable_invalide_invalide.tif','-r300');

close all; clf;

% comparaison avant/apr�s d�conjugualisation des ressources dans le calcul
% de l'AAH pour un couple ayant des enfants
% commenter la variable NbEnfants dans le fichier comparaison_AAH_deconjugualisee_concubinage_enfants.m
NbEnfants = 1; comparaison_AAH_deconjugalisee_concubinage_enfants;
export_fig(h1,'images_generees/Comparaison_AAH_deconjugalisee_1enfant_invalide_valide.tif','-r300');
export_fig(h2,'images_generees/Difference_AAH_deconjugalisee_1enfant_invalide_valide_3D.tif','-r300');
export_fig(h3,'images_generees/Difference_AAH_deconjugalisee_1enfant_invalide_valide_2D.tif','-r300');
NbEnfants = 2; comparaison_AAH_deconjugalisee_concubinage_enfants;
export_fig(h1,'images_generees/Comparaison_AAH_deconjugalisee_2enfants_invalide_valide.tif','-r300');
export_fig(h2,'images_generees/Difference_AAH_deconjugalisee_2enfants_invalide_valide_3D.tif','-r300');
export_fig(h3,'images_generees/Difference_AAH_deconjugalisee_2enfants_invalide_valide_2D.tif','-r300');

set(0,'DefaultFigureVisible','on');