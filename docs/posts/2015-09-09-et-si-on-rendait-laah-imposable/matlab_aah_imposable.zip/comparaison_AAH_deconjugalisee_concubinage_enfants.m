% Comparaison revenus r�els du couple en concubinage avec prise en compte de l'AAH ou non
% pour un conjoit valide ou non
% faut lancer AAH avant pour les variables globales
% type = 2; 

salaire_max = 4000;
step = 10;
x=0:step:salaire_max;
y=x;
dim = size(x,2);
aah_couple_enfants = zeros(dim);
aah_seul = zeros(dim);
%NbEnfants = 1;

for i=1:dim;
    for j=1:dim
        aah_couple_enfants(i,j) = abattements_couple_enfants(x(i),y(j),NbEnfants);
        aah_seul(i,j) = abattements_seul_enfants(x(i),NbEnfants);
  
    end
end


% Graphique : imp�ts avec prise en compte de l'AAH ou non

[X,Y] = meshgrid(x,y);
h1=figure;
surf(X,Y,aah_couple_enfants);
colormap(winter)
shading interp;
camlight('right','local'); lighting phong
%alpha(.4)
freezeColors
hold on;
surf(X,Y,aah_seul);
shading interp;
colormap(spring)
camlight('headlight','local'); lighting phong
%alpha(.4)
set(gcf, 'Color', [1,1,1]);
ylabel('Invalide','FontSize',12,'FontWeight','bold');
xlabel('Valide','FontSize',12,'FontWeight','bold');
zlabel('AAH vers�e','FontSize',12,'FontWeight','bold');
title(sprintf('Comparaison calcul AAH d�conjugalis�e - AAH couple avec %d enfants',NbEnfants),'FontSize',12,'Color','red','FontWeight','bold');

legend({'AAH couple','AAH seul'},'FontSize',12,'FontWeight','bold','Position',[0.70,0.75,0.25,0.1])

h2=figure;
diff = aah_seul-aah_couple_enfants;
surf(X,Y,diff);
shading interp;
camlight('right','local'); lighting phong
hold on;
mm = min(min(diff));
MM = max(max(diff));
surf([0 salaire_max],[0 salaire_max],repmat(mm-(MM-mm)/5, [2 2]),...
    diff,'facecolor','texture');
 
colormap(jet)
colorbar;
set(gcf, 'Color', [1,1,1]);
ylabel('Invalide','FontSize',12,'FontWeight','bold');
xlabel('Valide','FontSize',12,'FontWeight','bold');
zlabel('Diff�rence AAH','FontSize',12,'FontWeight','bold');
title(sprintf('Diff�rence calcul AAH d�conjugalis�e - AAH couple avec %d enfants',NbEnfants),'FontSize',12,'Color','red','FontWeight','bold');

h3=figure;
imagesc(diff)
ticklabels = 0:500:salaire_max;
ticks = linspace(1, size(diff, 2), numel(ticklabels));
set(gca, 'XTick', ticks, 'YTick', ticks, 'XTickLabel', ticklabels, 'YTickLabel', ticklabels)
set(gca, 'YDir', 'normal');
colormap(jet)
colorbar;
set(gcf, 'Color', [1,1,1]);
ylabel('Invalide','FontSize',12,'FontWeight','bold');
xlabel('Valide','FontSize',12,'FontWeight','bold');
title(sprintf('Diff�rence calcul AAH d�conjugalis�e - AAH couple avec %d enfants',NbEnfants),'FontSize',12,'Color','red','FontWeight','bold');
