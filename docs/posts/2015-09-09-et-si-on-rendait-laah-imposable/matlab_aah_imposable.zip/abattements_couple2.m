% Calcul pour un b�n�ficiaire en couple, l'AAH vers�e en fonction
% du salaire mensuel net imposable du b�n�ficiaire et du conjoint
function aah = abattements_couple2(x,y)
global plafond_couple plafond_seul smic;

if (x >= 0) && (x <= smic*0.3)
    assiette_x = round(0.2*(x*12));
else
    assiette_x = round(0.2*(smic*0.3*12)+0.6*(x*12-smic*0.3*12));
end

assiette_y = round(0.9*0.8*(y*12));

assiette = assiette_x+assiette_y;

if (assiette > plafond_couple)
    assiette = plafond_couple;
end

aah = (plafond_couple-assiette)/12;
if (aah > plafond_seul/12)
    aah = plafond_seul/12;
end

end