% Comparaison imp�ts avec prise en compte de l'AAH ou non
% pour un conjoit valide ou non
% faut lancer AAH avant pour les variables globales

%type = 2; 

salaire_max = 3000;
step = 10;
x=0:step:salaire_max;
y=x;
dim = size(x,2);
impots_mariage_non_aah = zeros(dim);
impots_mariage_aah = zeros(dim);

if type == 1

for i=1:dim;
    for j=1:dim
        impots_mariage_non_aah(i,j) = imposition_couple(x(i)+y(j),1);
        impots_mariage_aah(i,j) = imposition_couple(x(i)+abattements_seul(x(i))+y(j),1);
    end
end

else
    
for i=1:dim;
    for j=1:dim
        impots_mariage_non_aah(i,j) = imposition_couple(x(i)+y(j),2);
        impots_mariage_aah(i,j) = imposition_couple(x(i)+abattements_seul(x(i))+y(j)+abattements_seul(y(j)),2);
    end
end 
    
end

% Graphique : imp�ts avec prise en compte de l'AAH ou non

[X,Y] = meshgrid(x,y);
h1=figure;
surf(X,Y,impots_mariage_non_aah);
colormap(winter)
shading interp;
camlight('right','local'); lighting phong
%alpha(.4)
freezeColors
hold on;
surf(X,Y,impots_mariage_aah);
shading interp;
colormap(spring)
camlight('headlight','local'); lighting phong
%alpha(.4)
set(gcf, 'Color', [1,1,1]);
if type == 1
    ylabel('Invalide','FontSize',12,'FontWeight','bold');
    xlabel('Valide','FontSize',12,'FontWeight','bold');
    zlabel('Imp�ts mensuels','FontSize',12,'FontWeight','bold');
    title('Comparaison imp�ts invalide et valide mari�s avec/sans AAH imposable','FontSize',12,'Color','red','FontWeight','bold');
else
    ylabel('Invalide','FontSize',12,'FontWeight','bold');
    xlabel('Invalide','FontSize',12,'FontWeight','bold');
    zlabel('Imp�ts mensuels','FontSize',12,'FontWeight','bold');
    title('Comparaison imp�ts pour des personnes invalides mari�es avec/sans AAH imposable','FontSize',12,'Color','red','FontWeight','bold');
end
legend({'imp�ts sans AAH','imp�ts avec AAH'},'FontSize',12,'FontWeight','bold','Position',[0.70,0.75,0.25,0.1])

h2=figure;
diff = impots_mariage_aah-impots_mariage_non_aah;
surf(X,Y,diff);
shading interp;
camlight('right','local'); lighting phong
hold on;
mm = min(min(diff));
MM = max(max(diff));
surf([0 salaire_max],[0 salaire_max],repmat(mm-(MM-mm)/5, [2 2]),...
    diff,'facecolor','texture');
 
colormap(jet)
colorbar;
set(gcf, 'Color', [1,1,1]);
if type == 1
    ylabel('Invalide','FontSize',12,'FontWeight','bold');
    xlabel('Valide','FontSize',12,'FontWeight','bold');
    zlabel('Imp�ts mensuels','FontSize',12,'FontWeight','bold');
    title('Diff�rence imp�ts avec AAH - sans AAH pour une personne invalide et valide mari�es','FontSize',12,'Color','red','FontWeight','bold');
else
    ylabel('Invalide','FontSize',12,'FontWeight','bold');
    xlabel('Invalide','FontSize',12,'FontWeight','bold');
    zlabel('Imp�ts mensuels','FontSize',12,'FontWeight','bold');
    title('Diff�rence imp�ts avec AAH - sans AAH pour des personnes invalides mari�es','FontSize',12,'Color','red','FontWeight','bold');
end


h3=figure;
diffbin = im2bw(mat2gray(diff), 0.01);
imagesc(diffbin);
ticklabels = 0:200:salaire_max;
ticks = linspace(1, size(diffbin, 2), numel(ticklabels));
set(gca, 'XTick', ticks, 'YTick', ticks, 'XTickLabel', ticklabels, 'YTickLabel', ticklabels)
set(gca, 'YDir', 'normal');
colormap(jet)
set(gcf, 'Color', [1,1,1]);
if type == 1
    ylabel('Invalide','FontSize',12,'FontWeight','bold');
    xlabel('Valide','FontSize',12,'FontWeight','bold');
    zlabel('Imp�ts mensuels','FontSize',12,'FontWeight','bold');
    title('D�avantage fiscal pour une personne invalide et valide mari�es si AAH imposable (en rouge)','FontSize',12,'Color','red','FontWeight','bold');
else
    ylabel('Invalide','FontSize',12,'FontWeight','bold');
    xlabel('Invalide','FontSize',12,'FontWeight','bold');
    zlabel('Imp�ts mensuels','FontSize',12,'FontWeight','bold');
    title('D�avantage fiscal pour des personnes invalides mari�es si AAH imposable (en rouge)','FontSize',12,'Color','red','FontWeight','bold');
end

% pour exporter : export_fig(h,'essai.tif','-r300') car en eps ou pdf le
% Cdata RGB est mal g�r� � cause de freezecolor qui passe en RGB

