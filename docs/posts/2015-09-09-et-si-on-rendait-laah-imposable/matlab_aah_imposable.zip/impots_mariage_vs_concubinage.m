% Avantage fiscal ou non li� au mariage

%type = 1; % nb d'invalide dans le couple , � commenter pour Genere_images

salaire_max = 3000;
step = 10;
x=0:step:salaire_max;
y=x;
dim = size(x,2);
impots_mariage = zeros(dim);
impots_concubinage = zeros(dim);

if type == 0

% 1 - Pour 2 personnes valides (sans enfant)

for i=1:dim;
    for j=1:dim
        impots_mariage(i,j) = 12*imposition_couple(x(i)+y(j),0);
        impots_concubinage(i,j) = 12*(imposition(x(i),0)+imposition(y(j),0));
    end
end

elseif type == 1
    
% 2 - Pour une personne valide et une personne invalide (sans enfant)
    
for i=1:dim;
    for j=1:dim
        impots_mariage(i,j) = 12*imposition_couple(x(i)+y(j),1);
        impots_concubinage(i,j) = 12*(imposition(x(i),1)+imposition(y(j),0));
    end
end

else
    
% 3 - Pour deux personnes invalides (sans enfant)
    
for i=1:dim;
    for j=1:dim
        impots_mariage(i,j) = 12*imposition_couple(x(i)+y(j),2);
        impots_concubinage(i,j) = 12*(imposition(x(i),1)+imposition(y(j),1));
    end
end
    
end

% Graphique : D�claration commune (mariage) VS s�par�es (concubinage)

[X,Y] = meshgrid(x,y);
h1=figure;
surf(X,Y,impots_mariage);
colormap(winter)
shading interp;
camlight('right','local'); lighting phong
%alpha(.4)
freezeColors
hold on;
surf(X,Y,impots_concubinage);
shading interp;
colormap(spring)
camlight('headlight','local'); lighting phong
%alpha(.4)
set(gcf, 'Color', [1,1,1]);
if type == 0
    ylabel('Valide','FontSize',12,'FontWeight','bold');
    xlabel('Valide','FontSize',12,'FontWeight','bold');
    zlabel('Imp�ts annuels','FontSize',12,'FontWeight','bold');
    title('Comparaison imp�ts pour des personnnes valides mari�es ou en concubinage','FontSize',12,'Color','red','FontWeight','bold');
elseif type == 1
    ylabel('Invalide','FontSize',12,'FontWeight','bold');
    xlabel('Valide','FontSize',12,'FontWeight','bold');
    zlabel('Imp�ts annuels','FontSize',12,'FontWeight','bold');
    title('Comparaison imp�ts une personne invalide et valide, mari�es ou en concubinage','FontSize',12,'Color','red','FontWeight','bold');
else
    ylabel('Invalide','FontSize',12,'FontWeight','bold');
    xlabel('Invalide','FontSize',12,'FontWeight','bold');
    zlabel('Imp�ts annuels','FontSize',12,'FontWeight','bold');
    title('Comparaison imp�ts pour des personnnes invalides mari�es ou en concubinage','FontSize',12,'Color','red','FontWeight','bold');
end
legend({'imp�ts mariage','imp�ts concubinage'},'FontSize',12,'FontWeight','bold','Position',[0.70,0.75,0.25,0.1])

h2=figure;
diff = impots_mariage-impots_concubinage;
surf(X,Y,diff);
shading interp;
camlight('right','local'); lighting phong
hold on;
mm = min(min(diff));
MM = max(max(diff));
surf([0 salaire_max],[0 salaire_max],repmat(mm-(MM-mm)/5, [2 2]),...
    diff,'facecolor','texture');
 
colormap(jet)
colorbar;
set(gcf, 'Color', [1,1,1]);
if type == 0
    ylabel('Valide','FontSize',12,'FontWeight','bold');
    xlabel('Valide','FontSize',12,'FontWeight','bold');
    zlabel('Imp�ts annuels','FontSize',12,'FontWeight','bold');
    title('Diff�rence imp�ts mariage - concubinage pour des personnnes valides','FontSize',12,'Color','red','FontWeight','bold');
elseif type == 1
    ylabel('Invalide','FontSize',12,'FontWeight','bold');
    xlabel('Valide','FontSize',12,'FontWeight','bold');
    zlabel('Imp�ts annuels','FontSize',12,'FontWeight','bold');
    title('Diff�rence imp�ts mariage - concubinage pour une personne invalide et valide','FontSize',12,'Color','red','FontWeight','bold');
else
    ylabel('Invalide','FontSize',12,'FontWeight','bold');
    xlabel('Invalide','FontSize',12,'FontWeight','bold');
    zlabel('Imp�ts annuels','FontSize',12,'FontWeight','bold');
    title('Diff�rence imp�ts mariage - concubinage pour des personnnes invalides','FontSize',12,'Color','red','FontWeight','bold');
end


h3=figure;
diffbin = im2bw(diff, 0);
imagesc(diffbin);
ticklabels = 0:200:salaire_max;
ticks = linspace(1, size(diffbin, 2), numel(ticklabels));
set(gca, 'XTick', ticks, 'YTick', ticks, 'XTickLabel', ticklabels, 'YTickLabel', ticklabels)
set(gca, 'YDir', 'normal');
colormap(jet)
set(gcf, 'Color', [1,1,1]);
if type == 0
    ylabel('Valide','FontSize',12,'FontWeight','bold');
    xlabel('Valide','FontSize',12,'FontWeight','bold');
    title('Zones de d�avantage fiscal pour des personnnes valides (en rouge)','FontSize',12,'Color','red','FontWeight','bold');
elseif type == 1
    ylabel('Invalide','FontSize',12,'FontWeight','bold');
    xlabel('Valide','FontSize',12,'FontWeight','bold');
    zlabel('Imp�ts annuels','FontSize',12,'FontWeight','bold');
    title('Zones de d�avantage fiscal pour une personne invalide et valide (en rouge)','FontSize',12,'Color','red','FontWeight','bold');
else
    ylabel('Invalide','FontSize',12,'FontWeight','bold');
    xlabel('Invalide','FontSize',12,'FontWeight','bold');
    zlabel('Imp�ts annuels','FontSize',12,'FontWeight','bold');
    title('Zones de d�avantage fiscal pour des personnes invalides (en rouge)','FontSize',12,'Color','red','FontWeight','bold');
end

% pour exporter : export_fig(h,'essai.tif','-r300') car en eps ou pdf le
% Cdata RGB est mal g�r� � cause de freezecolor qui passe en RGB
