% Comparaison revenus r�els du couple mari� avec prise en compte de l'AAH ou non
% pour un conjoit valide ou non
% faut lancer AAH avant pour les variables globales
% type = 2; 

salaire_max = 3000;
step = 10;
x=0:step:salaire_max;
y=x;
dim = size(x,2);
revenus_mariage_non_aah = zeros(dim);
revenus_mariage_aah = zeros(dim);
aah_couple = zeros(dim);
MF = 786.24; % montant forfaitaire couple
FL = 125.8;  % forfait logement
RSA_1 = zeros(dim); % avec AAH(x)

if type == 1

for i=1:dim;
    for j=1:dim
        aah_couple(i,j) = abattements_couple2(x(i),y(j));
         RSA_1(i,j) = MF+0.62*(x(i)+y(j)+aah_seul(i,j))-(x(i)+aah_seul(i,j)+y(j)+FL);
        if RSA_1(i,j) < 0
            RSA_1(i,j)=0;
        end
        revenus_mariage_non_aah(i,j) = x(i)+aah_couple(i,j)+y(j)-imposition_couple(x(i)+y(j),1);
        revenus_mariage_aah(i,j) = x(i)+abattements_seul(x(i))+y(j)+RSA_1(i,j)-imposition_couple(x(i)+abattements_seul(x(i))+y(j),1);
    end
end

else
    
for i=1:dim;
    for j=1:dim
        aah_couple(i,j) = abattements_couple2(x(i),y(j));
        revenus_mariage_non_aah(i,j) = x(i)+aah_couple(i,j)+y(j)-imposition_couple(x(i)+y(j),1);
        revenus_mariage_aah(i,j) = x(i)+abattements_seul(x(i))+y(j)-imposition_couple(x(i)+abattements_seul(x(i))+y(j),2);
    end
end
    
end

% Graphique : imp�ts avec prise en compte de l'AAH ou non

[X,Y] = meshgrid(x,y);
h1=figure;
surf(X,Y,revenus_mariage_non_aah);
colormap(winter)
shading interp;
camlight('right','local'); lighting phong
%alpha(.4)
freezeColors
hold on;
surf(X,Y,revenus_mariage_aah);
shading interp;
colormap(spring)
camlight('headlight','local'); lighting phong
%alpha(.4)
set(gcf, 'Color', [1,1,1]);
if type == 1
    ylabel('Invalide','FontSize',12,'FontWeight','bold');
    xlabel('Valide','FontSize',12,'FontWeight','bold');
    zlabel('Revenus r�els du couple','FontSize',12,'FontWeight','bold');
    title('Revenus r�els mensuels du couple invalide et valide mari�s avec/sans AAH imposable','FontSize',12,'Color','red','FontWeight','bold');
else
    ylabel('Invalide','FontSize',12,'FontWeight','bold');
    xlabel('Invalide','FontSize',12,'FontWeight','bold');
    zlabel('Revenus r�els du couple','FontSize',12,'FontWeight','bold');
    title('Revenus r�els mensuels du couple des personnnes invalides mari�es avec/sans AAH imposable','FontSize',12,'Color','red','FontWeight','bold');
end
legend({'Revenus sans AAH','Revenus avec AAH'},'FontSize',12,'FontWeight','bold','Position',[0.70,0.75,0.25,0.1])

h2=figure;
diff = revenus_mariage_aah-revenus_mariage_non_aah;
surf(X,Y,diff);
shading interp;
camlight('right','local'); lighting phong
hold on;
mm = min(min(diff));
MM = max(max(diff));
surf([0 salaire_max],[0 salaire_max],repmat(mm-(MM-mm)/5, [2 2]),...
    diff,'facecolor','texture');
 
colormap(jet)
colorbar;
set(gcf, 'Color', [1,1,1]);
if type == 1
    ylabel('Invalide','FontSize',12,'FontWeight','bold');
    xlabel('Valide','FontSize',12,'FontWeight','bold');
    zlabel('Diff�rence revenus','FontSize',12,'FontWeight','bold');
    title('Diff�rence revenus avec AAH - sans AAH pour une personne invalide et valide mari�es','FontSize',12,'Color','red','FontWeight','bold');
else
    ylabel('Invalide','FontSize',12,'FontWeight','bold');
    xlabel('Invalide','FontSize',12,'FontWeight','bold');
    zlabel('Diff�rence revenus','FontSize',12,'FontWeight','bold');
    title('Diff�rence revenus avec AAH - sans AAH pour des personnes invalides mari�es','FontSize',12,'Color','red','FontWeight','bold');
end

h3=figure;
surf(X,Y,aah_couple);
colormap(jet)
shading interp;
camlight('headlight','local'); lighting phong
hold on;
surf([0 salaire_max],[0 salaire_max],repmat(0, [2 2]),...
    aah_couple,'facecolor','texture');
 
colormap(jet)
colorbar;
set(gcf, 'Color', [1,1,1]);
ylabel('Invalide','FontSize',12,'FontWeight','bold');
xlabel('Valide','FontSize',12,'FontWeight','bold');
zlabel('AAH couple','FontSize',12,'FontWeight','bold');
title('Montant AAH vers� en fonction du salaire du b�n�ficiaire et du conjoint','FontSize',12,'Color','red','FontWeight','bold');

h4=figure;
imagesc(aah_couple)
ticklabels = 0:200:salaire_max;
ticks = linspace(1, size(aah_couple, 2), numel(ticklabels));
set(gca, 'XTick', ticks, 'YTick', ticks, 'XTickLabel', ticklabels, 'YTickLabel', ticklabels)
set(gca, 'YDir', 'normal');
colormap(jet)
colorbar;
set(gcf, 'Color', [1,1,1]);
ylabel('Invalide','FontSize',12,'FontWeight','bold');
xlabel('Valide','FontSize',12,'FontWeight','bold');
title('Montant AAH vers� en fonction du salaire du b�n�ficiaire et du conjoint','FontSize',12,'Color','red','FontWeight','bold');
