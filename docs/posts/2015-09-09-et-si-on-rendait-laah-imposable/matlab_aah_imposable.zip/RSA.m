% Etude du RSA en couple
type = 1; 
NbEnfants = 2;
impot = 1;
mariage = 1;

MF_seul = 524.16;
FL_seul = 62.90;
if NbEnfants == 0
    MF = 786.24; % montant forfaitaire couple
    FL = 125.8;  % forfait logement
elseif NbEnfants == 1
    MF = 943.49;
    FL = 155.68;
elseif NbEnfants == 2
    MF = 1100.74;
    FL = 155.68;
else
    MF = 1100.74 + (NbEnfants-2)*209.66;
    FL = 155.68;
end
salaire_max = 3000;
step = 10;
x=0:step:salaire_max;
y=x;
dim = size(x,2);
revenus_non_aah = zeros(dim);
revenus_aah = zeros(dim);
aah_couple = zeros(dim);
aah_seul = zeros(dim);
RSA_0 = zeros(1,dim); % RSA c�libataire
RSA_1 = zeros(dim); % avec AAH(x)
RSA_2 = zeros(dim); % avec AAH(x,y), vaut 0
impot_non_aah = zeros(dim);
impot_aah = zeros(dim);
diff_compensee = zeros(dim);


if type == 1

for i=1:dim;
    RSA_0(i) = MF_seul-FL_seul-0.38*x(i);
    for j=1:dim
        aah_couple(i,j) = abattements_couple_enfants(x(i),y(j),NbEnfants);
        aah_seul(i,j) = abattements_seul_enfants(x(i),NbEnfants);
        RSA_1(i,j) = MF+0.62*(x(i)+y(j)+aah_seul(i,j))-(x(i)+aah_seul(i,j)+y(j)+FL);
        if RSA_1(i,j) < 0
            RSA_1(i,j)=0;
        end
        if impot
            if mariage
                impot_non_ahh(i,j) = imposition_couple_enfants(x(i)+y(j),1,NbEnfants);
                impot_aah(i,j) = imposition_couple_enfants(x(i)+aah_seul(i,j)+y(j),1,NbEnfants);
            else
                impot_non_ahh(i,j) = imposition_enfants(x(i),1,0)+imposition_enfants(y(j),0,NbEnfants);
                impot_aah(i,j) = imposition_enfants(x(i)+aah_seul(i,j),1,0)+imposition_enfants(y(j),0,NbEnfants);
            end
        end
        RSA_2(i,j) = MF+0.62*(x(i)+y(j))-(x(i)+aah_couple(i,j)+y(j)+FL);
        revenus_non_aah(i,j) = x(i)+aah_couple(i,j)+y(j)-impot_non_aah(i,j);
        revenus_aah(i,j) = x(i)+aah_seul(i,j)+y(j)+RSA_1(i,j)-impot_aah(i,j);
    end
end

else

for i=1:dim;
    for j=1:dim
        aah_couple(i,j) = abattements_couple2(x(i),y(j));
        aah_seul(i,j) = abattements_seul(x(i));
        revenus_non_aah(i,j) = x(i)+aah_couple(i,j)+y(j)+abattements_couple2(y(j),x(j))-imposition(x(i),1)-imposition(y(j),1);
        revenus_aah(i,j) = x(i)+aah_seul(i,j)+y(j)+abattements_seul(y(j))-imposition(x(i)+aah_seul(i,j),1)-imposition(y(j)+abattements_seul(y(j)),1);
    end
end
    
end

h0=figure;
plot(x,RSA_0.*(RSA_0>0),'r');
set(gcf, 'Color', [1,1,1]);
ylabel('RSA vers�','FontSize',12,'FontWeight','bold');
xlabel('Salaire','FontSize',12,'FontWeight','bold');
title('RSA vers� en fonction du salaire','FontSize',12,'Color','red','FontWeight','bold');

[X,Y] = meshgrid(x,y);
h1=figure;
surf(X,Y,RSA_1);
colormap(winter)
shading interp;
camlight('right','local'); lighting phong
%alpha(.4)
freezeColors
hold on;
surf(X,Y,RSA_2);
shading interp;
colormap(spring)
camlight('headlight','local'); lighting phong
%alpha(.4)
set(gcf, 'Color', [1,1,1]);
if type == 1
    ylabel('Invalide','FontSize',12,'FontWeight','bold');
    xlabel('Valide','FontSize',12,'FontWeight','bold');
    zlabel('Revenus r�els','FontSize',12,'FontWeight','bold');
    title('RSA couple avec/sans AAH d�conjugualis�e','FontSize',12,'Color','red','FontWeight','bold');
else
    ylabel('Invalide','FontSize',12,'FontWeight','bold');
    xlabel('Invalide','FontSize',12,'FontWeight','bold');
    zlabel('Revenus r�els','FontSize',12,'FontWeight','bold');
    title('Comparaison revenus pour des personnes invalides concubinage avec/sans AAH imposable','FontSize',12,'Color','red','FontWeight','bold');
end
legend({'RSA d�conj','RSA conj'},'FontSize',12,'FontWeight','bold','Position',[0.70,0.75,0.25,0.1])

h2=figure;
imagesc(RSA_1);
ticklabels = 0:200:salaire_max;
ticks = linspace(1, size(RSA_1, 2), numel(ticklabels));
set(gca, 'XTick', ticks, 'YTick', ticks, 'XTickLabel', ticklabels, 'YTickLabel', ticklabels)
set(gca, 'YDir', 'normal');
colormap jet;
colorbar;
set(gcf, 'Color', [1,1,1]);
ylabel('Invalide','FontSize',12,'FontWeight','bold');
xlabel('Valide','FontSize',12,'FontWeight','bold');
title('RSA vers� au conjoint apr�s d�conjugualisation','FontSize',12,'Color','red','FontWeight','bold');

h3=figure;
diff = aah_seul-aah_couple;
diff_revenus = revenus_aah-revenus_non_aah;
imagesc(diff);
ticklabels = 0:200:salaire_max;
ticks = linspace(1, size(diff, 2), numel(ticklabels));
set(gca, 'XTick', ticks, 'YTick', ticks, 'XTickLabel', ticklabels, 'YTickLabel', ticklabels)
set(gca, 'YDir', 'normal');
colormap jet;
colorbar;
caxis([min(min(min(diff)),min(min(diff_revenus))),max(max(max(diff)),max(max(diff_revenus)))]);
set(gcf, 'Color', [1,1,1]);
ylabel('Invalide','FontSize',12,'FontWeight','bold');
xlabel('Valide','FontSize',12,'FontWeight','bold');
title('Diff�rence AAH seul - AAH en couple','FontSize',12,'Color','red','FontWeight','bold');

h4=figure;
imagesc(revenus_non_aah);
ticklabels = 0:200:salaire_max;
ticks = linspace(1, size(diff, 2), numel(ticklabels));
set(gca, 'XTick', ticks, 'YTick', ticks, 'XTickLabel', ticklabels, 'YTickLabel', ticklabels)
set(gca, 'YDir', 'normal');
colormap jet;
colorbar;
set(gcf, 'Color', [1,1,1]);
ylabel('Invalide','FontSize',12,'FontWeight','bold');
xlabel('Valide','FontSize',12,'FontWeight','bold');
title('Revenus foyer sans AAH deconjugualis�e','FontSize',12,'Color','red','FontWeight','bold');

h5=figure;
imagesc(revenus_aah);
ticklabels = 0:200:salaire_max;
ticks = linspace(1, size(diff, 2), numel(ticklabels));
set(gca, 'XTick', ticks, 'YTick', ticks, 'XTickLabel', ticklabels, 'YTickLabel', ticklabels)
set(gca, 'YDir', 'normal');
colormap jet;
cmin=min(min(revenus_non_aah));cmax=2*salaire_max;caxis([cmin cmax]);colorbar;
set(gcf, 'Color', [1,1,1]);
ylabel('Invalide','FontSize',12,'FontWeight','bold');
xlabel('Valide','FontSize',12,'FontWeight','bold');
title('Revenus foyer avec AAH deconjugualis�e','FontSize',12,'Color','red','FontWeight','bold');

h6=figure;
surf(X,Y,revenus_non_aah);
colormap(winter)
shading interp;
camlight('right','local'); lighting phong
%alpha(.4)
freezeColors
hold on;
surf(X,Y,revenus_aah);
shading interp;
colormap(spring)
camlight('headlight','local'); lighting phong
%alpha(.4)
set(gcf, 'Color', [1,1,1]);
ylabel('Invalide','FontSize',12,'FontWeight','bold');
xlabel('Valide','FontSize',12,'FontWeight','bold');
zlabel('Revenus r�els','FontSize',12,'FontWeight','bold');
title('Comparaison revenus invalide et valide concubinage avec/sans AAH imposable','FontSize',12,'Color','red','FontWeight','bold');
legend({'Revenus sans AAH','Revenus avec AAH'},'FontSize',12,'FontWeight','bold','Position',[0.70,0.75,0.25,0.1])

h7=figure;
imagesc(diff_revenus)
ticklabels = 0:200:salaire_max;
ticks = linspace(1, size(diff_revenus, 2), numel(ticklabels));
set(gca, 'XTick', ticks, 'YTick', ticks, 'XTickLabel', ticklabels, 'YTickLabel', ticklabels)
set(gca, 'YDir', 'normal');
colormap(jet)
colorbar;
caxis([min(min(min(diff)),min(min(diff_revenus))),max(max(max(diff)),max(max(diff_revenus)))]);
set(gcf, 'Color', [1,1,1]);
ylabel('Invalide','FontSize',12,'FontWeight','bold');
xlabel('Valide','FontSize',12,'FontWeight','bold');
title('Diff�rence calcul revenus avec/sans AAH d�conjugualis�e','FontSize',12,'Color','red','FontWeight','bold');

export_fig(h3,'images_generees/tada.tif','-r300');
export_fig(h7,'images_generees/tada2.tif','-r300');

% export_fig(h0,'images_generees/RSA_seul.tif','-r300');
% export_fig(h1,'images_generees/Comparaison_RSA_1_2.tif','-r300');
% export_fig(h2,'images_generees/RSA_compensatoire.tif','-r300');
% export_fig(h3,'images_generees/Difference_AAH_compensee.tif','-r300');
% export_fig(h4,'images_generees/Revenus_foyer_concubinage_sans_aah_sans_impot.tif','-r300');
% export_fig(h5,'images_generees/Revenus_foyer_concubinage_aah_sans_impot.tif','-r300');
% export_fig(h6,'images_generees/Comparaison_revenus_foyer_concubinage_sans_impot.tif','-r300');
% export_fig(h6,'images_generees/Comparaison_revenus_foyer_concubinage_sans_impot.tif','-r300');