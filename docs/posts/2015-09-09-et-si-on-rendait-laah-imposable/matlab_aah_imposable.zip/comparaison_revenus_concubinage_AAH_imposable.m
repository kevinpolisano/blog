% Comparaison revenus r�els du couple en concubinage avec prise en compte de l'AAH ou non
% pour un conjoit valide ou non
% faut lancer AAH avant pour les variables globales
 type = 1; 

salaire_max = 3000;
step = 10;
x=0:step:salaire_max;
y=x;
dim = size(x,2);
revenus_concubinage_non_aah = zeros(dim);
revenus_concubinage_aah = zeros(dim);
aah_couple = zeros(dim);
aah_seul = zeros(dim);
MF = 786.24; % montant forfaitaire couple
FL = 125.8;  % forfait logement
RSA_1 = zeros(dim); % avec AAH(x)

if type == 1

for i=1:dim;
    for j=1:dim
        aah_couple(i,j) = abattements_couple2(x(i),y(j));
        aah_seul(i,j) = abattements_seul(x(i));
         RSA_1(i,j) = MF+0.62*(x(i)+y(j)+aah_seul(i,j))-(x(i)+aah_seul(i,j)+y(j)+FL);
        if RSA_1(i,j) < 0
            RSA_1(i,j)=0;
        end
        revenus_concubinage_non_aah(i,j) = x(i)+aah_couple(i,j)+y(j)-imposition(x(i),1)-imposition(y(j),0);
        revenus_concubinage_aah(i,j) = x(i)+aah_seul(i,j)+y(j)+RSA_1(i,j)-imposition(x(i)+aah_seul(i,j),1)-imposition(y(j),0);
    end
end

else

for i=1:dim;
    for j=1:dim
        aah_couple(i,j) = abattements_couple2(x(i),y(j));
        aah_seul(i,j) = abattements_seul(x(i));
        revenus_concubinage_non_aah(i,j) = x(i)+aah_couple(i,j)+y(j)+abattements_couple2(y(j),x(j))-imposition(x(i),1)-imposition(y(j),1);
        revenus_concubinage_aah(i,j) = x(i)+aah_seul(i,j)+y(j)+abattements_seul(y(j))-imposition(x(i)+aah_seul(i,j),1)-imposition(y(j)+abattements_seul(y(j)),1);
    end
end
    
end

% Graphique : imp�ts avec prise en compte de l'AAH ou non

[X,Y] = meshgrid(x,y);
h1=figure;
surf(X,Y,revenus_concubinage_non_aah);
colormap(winter)
shading interp;
camlight('right','local'); lighting phong
%alpha(.4)
freezeColors
hold on;
surf(X,Y,revenus_concubinage_aah);
shading interp;
colormap(spring)
camlight('headlight','local'); lighting phong
%alpha(.4)
set(gcf, 'Color', [1,1,1]);
if type == 1
    ylabel('Invalide','FontSize',12,'FontWeight','bold');
    xlabel('Valide','FontSize',12,'FontWeight','bold');
    zlabel('Revenus r�els','FontSize',12,'FontWeight','bold');
    title('Comparaison revenus invalide et valide concubinage avec/sans AAH imposable','FontSize',12,'Color','red','FontWeight','bold');
else
    ylabel('Invalide','FontSize',12,'FontWeight','bold');
    xlabel('Invalide','FontSize',12,'FontWeight','bold');
    zlabel('Revenus r�els','FontSize',12,'FontWeight','bold');
    title('Comparaison revenus pour des personnes invalides concubinage avec/sans AAH imposable','FontSize',12,'Color','red','FontWeight','bold');
end
legend({'Revenus sans AAH','Revenus avec AAH'},'FontSize',12,'FontWeight','bold','Position',[0.70,0.75,0.25,0.1])

h2=figure;
surf(X,Y,aah_couple);
colormap(winter)
shading interp;
camlight('right','local'); lighting phong
%alpha(.4)
freezeColors
hold on;
surf(X,Y,aah_seul);
shading interp;
colormap(spring)
camlight('headlight','local'); lighting phong
%alpha(.4)
set(gcf, 'Color', [1,1,1]);
ylabel('Invalide','FontSize',12,'FontWeight','bold');
xlabel('Valide','FontSize',12,'FontWeight','bold');
zlabel('AAH vers�e','FontSize',12,'FontWeight','bold');
title('Comparaison calcul AAH seul - AAH couple','FontSize',12,'Color','red','FontWeight','bold');

legend({'AAH couple','AAH seul'},'FontSize',12,'FontWeight','bold','Position',[0.70,0.75,0.25,0.1])

h3=figure;
diff = aah_seul-aah_couple;
surf(X,Y,diff);
shading interp;
camlight('right','local'); lighting phong
hold on;
mm = min(min(diff));
MM = max(max(diff));
surf([0 salaire_max],[0 salaire_max],repmat(mm-(MM-mm)/5, [2 2]),...
    diff,'facecolor','texture');
 
colormap(jet)
colorbar;
set(gcf, 'Color', [1,1,1]);
ylabel('Invalide','FontSize',12,'FontWeight','bold');
xlabel('Valide','FontSize',12,'FontWeight','bold');
zlabel('Diff�rence AAH','FontSize',12,'FontWeight','bold');
title('Diff�rence calcul AAH seul - AAH couple ','FontSize',12,'Color','red','FontWeight','bold');

h4=figure;
imagesc(diff)
ticklabels = 0:200:salaire_max;
ticks = linspace(1, size(diff, 2), numel(ticklabels));
set(gca, 'XTick', ticks, 'YTick', ticks, 'XTickLabel', ticklabels, 'YTickLabel', ticklabels)
set(gca, 'YDir', 'normal');
colormap(jet)
colorbar;
set(gcf, 'Color', [1,1,1]);
ylabel('Invalide','FontSize',12,'FontWeight','bold');
xlabel('Valide','FontSize',12,'FontWeight','bold');
title('Diff�rence calcul AAH seul - AAH couple','FontSize',12,'Color','red','FontWeight','bold');

h5=figure;
imagesc(diff>-2 & diff<2);
ticklabels = 0:200:salaire_max;
ticks = linspace(1, size(diff, 2), numel(ticklabels));
set(gca, 'XTick', ticks, 'YTick', ticks, 'XTickLabel', ticklabels, 'YTickLabel', ticklabels)
set(gca, 'YDir', 'normal');
colormap jet;
set(gcf, 'Color', [1,1,1]);
ylabel('Invalide','FontSize',12,'FontWeight','bold');
xlabel('Valide','FontSize',12,'FontWeight','bold');
title('Zone nulle de d�marcation (en rouge)','FontSize',12,'Color','red','FontWeight','bold');

