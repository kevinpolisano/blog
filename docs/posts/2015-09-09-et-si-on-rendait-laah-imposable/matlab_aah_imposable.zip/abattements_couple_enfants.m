% Calcul pour un b�n�ficiaire en couple, l'AAH vers�e en fonction
% du salaire mensuel net imposable du b�n�ficiaire et du conjoint
% requiert de lancer AAHcouple.m
function aah = abattements_couple_enfants(x,y,NbEnfants)
global plafond_couple EnfantCharge plafond_seul smic;
plafond_couple_enfants = plafond_couple + NbEnfants*EnfantCharge;

if (x >= 0) && (x <= smic*0.3)
    assiette_x = round(0.2*(x*12));
else
    assiette_x = round(0.2*(smic*0.3*12)+0.6*(x*12-smic*0.3*12));
end

assiette_y = round(0.9*0.8*(y*12));

assiette = assiette_x+assiette_y;

if (assiette > plafond_couple_enfants)
    assiette = plafond_couple_enfants;
end

aah = (plafond_couple_enfants-assiette)/12;
if (aah > plafond_seul/12)
    aah = plafond_seul/12;
end

end