% Calcul pour un b�n�ficiaire seul l'AAH vers�e en fonction
% du salaire mensuel net imposable qu'il per�oit
function aah = abattements_seul_enfants(salaire,NbEnfants)
global smic;
global plafond_seul EnfantCharge;
plafond_seul_enfants = plafond_seul + NbEnfants*EnfantCharge;
%salaire_max = (plafond_seul_enfants+0.4*(smic*0.3*12))/(12*0.6);

if (salaire >= 0) && (salaire <= smic*0.3)
    assiette = round(0.2*(salaire*12));
else 
    assiette = round(0.2*(smic*0.3*12)+0.6*(salaire*12-smic*0.3*12));
end
assiette = min(assiette,plafond_seul_enfants);
aah = (plafond_seul_enfants-assiette)/12;
if aah > plafond_seul/12
    aah = plafond_seul/12;
end

end