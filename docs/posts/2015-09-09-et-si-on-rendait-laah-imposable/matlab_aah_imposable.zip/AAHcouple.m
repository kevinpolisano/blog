global smic plafond_seul aah_taux_plein mva plafond_couple EnfantCharge;

% Chiffres de l'ann�e 2015
smic = 1457.52 ; 
aah_taux_plein = 800.45; 
plafond_couple = 2*12*aah_taux_plein;
EnfantCharge = 4802.7;
mva = 104.77;
salaire_critique_min = plafond_seul/(12*0.9*0.8);
salaire_critique_max = plafond_couple/(12*0.9*0.8);

aah_mva = aah_taux_plein+mva;
salaire_max = 2500;

abs_salaires = 0:0.1:salaire_max;
ord_ressources_tot = zeros(1,length(abs_salaires));
ord_aah = zeros(1,length(abs_salaires));

for i=1:length(ord_ressources_tot)
    ord_aah(i) = abattements_couple(abs_salaires(i));
    ord_ressources_tot(i) = ord_aah(i)+abs_salaires(i);
end



figure1 = figure('Color',[1 1 1]);
hold on;
h1=plot(abs_salaires,ord_ressources_tot,'Color','y','LineWidth',2);
h2=plot(abs_salaires,abs_salaires,'Color','b','LineWidth',2);
h3=plot(abs_salaires,ord_aah,'Color','r','LineWidth',2);
plot([salaire_critique_min salaire_critique_min],[0 2500],'Color',[1 215 96]/255,'LineWidth',1,'Linestyle','--')
plot([salaire_critique_max salaire_critique_max],[0 2500],'Color',[1 215 96]/255,'LineWidth',1,'Linestyle','--')

legend1 = legend([h2 h3 h1],{'conjoint','AAH','couple'});

% Create xlabel
xlabel({'Salaire net imposable du conjoint (en euros)'},'FontSize',12);

% Create ylabel
ylabel({'Ressources per�ues (en euros)'},'FontSize',12);

%
title('Impact du salaire du conjoint sur l''AAH vers�e (b�n�ficiaire sans revenus)','FontSize',12,'Color','red');


%legend1 = legend(axes1,'show');
set(legend1,...
    'Position',[0.834689049121225 0.627343397926993 0.144761153672826 0.111923539131741]);

% Create textbox
annotation(figure1,'textbox',...
    [0.562071428571428 0.86809523809524 0.250785714285714 0.0428571428571479],...
    'String',{'AAH diminu�e'},...
    'FontSize',12,...
    'FitBoxToText','off',...
    'LineStyle','none',...
    'Color',[0.870588235294118 0.490196078431373 0]);

% Create textbox
annotation(figure1,'textbox',...
    [0.824571428571428 0.52761904761905 0.250785714285714 0.0428571428571479],...
    'String',{'AAH supprim�e'},...
    'FontSize',12,...
    'FitBoxToText','off',...
    'LineStyle','none',...
    'Color',[1 0 0]);

% Create textbox
annotation(figure1,'textbox',...
    [0.215285714285714 0.866666666666667 0.250785714285714 0.0428571428571479],...
    'String',{'AAH conserv�e'},...
    'FontSize',12,...
    'FitBoxToText','off',...
    'LineStyle','none',...
    'Color',[0 0.498039215686275 0]);

% Create textbox
annotation(figure1,'textbox',...
    [0.829928571428569 0.252380952380953 0.15757142857143 0.156190476190484],...
    'String',{'D�pense','financi�re','totale vis � vis','du conjoint'},...
    'FontSize',12,...
    'FitBoxToText','off',...
    'LineStyle',':',...
    'Color',[1 0 0]);

