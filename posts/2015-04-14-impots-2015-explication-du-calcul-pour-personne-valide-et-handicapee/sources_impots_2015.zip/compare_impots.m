salaires = load('x_salaires.mat');
salaires = salaires.abs_salaires;

impots_invalide = load('y_impots_invalide.mat');
impots_invalide = impots_invalide.ord_impots;

impots_valide = load('y_impots_valide.mat');
impots_valide = impots_valide.ord_impots;

impots_invalide_2014 = load('y_impots_invalide_2014.mat');
impots_invalide_2014 = impots_invalide_2014.ord_impots;

impots_valide_2014 = load('y_impots_valide_2014.mat');
impots_valide_2014 = impots_valide_2014.ord_impots;

fig1 = figure('Color',[1 1 1]);
plot(salaires,impots_valide,'Color','b','LineWidth',2);
hold on;
plot(salaires,impots_invalide,'Color','r','LineWidth',2);

% Create xlabel
xlabel({'salaire mensuel net imposable (en euros)'});

% Create ylabel
ylabel({'imp�t sur le revenu mensuel (en euros)'});

% Create title
title({'COMPARAISON DES IMPOTS POUR UNE PERSONNE INVALIDE OU NON'});

% Create legend
legend1 = legend(' impot personne valide',' impot personne invalide');
set(legend1,...
    'Position',[0.525760477692654 0.795202418506835 0.282261153672826 0.0773978518852336]);

fig2 = figure('Color',[1 1 1]);
pourcentage_salaire_valide = 100*impots_valide./(salaires+eps);
pourcentage_salaire_invalide = 100*impots_invalide./(salaires+eps);
plot(salaires,pourcentage_salaire_valide,'Color','b','LineWidth',2);
hold on;
plot(salaires,pourcentage_salaire_invalide,'Color','r','LineWidth',2);

% Create xlabel
xlabel({'salaire mensuel net imposable (en euros)'});

% Create ylabel
ylabel({'imp�t sur le revenu mensuel (en % du salaire)'});

% Create title
title({'COMPARAISON DES IMPOTS POUR UNE PERSONNE INVALIDE OU NON'});

% Create legend
legend1 = legend(' impot personne valide',' impot personne invalide');
set(legend1,...
    'Position',[0.525760477692654 0.795202418506835 0.282261153672826 0.0773978518852336]);

fig3 = figure('Color',[1 1 1]);
plot(salaires,12*impots_valide,'Color','g','LineWidth',2);
hold on;
plot(salaires,12*impots_valide_2014,'Color','b','LineWidth',2);
plot(salaires,12*impots_invalide,'Color','m','LineWidth',2);
plot(salaires,12*impots_invalide_2014,'Color','r','LineWidth',2);
axis([0 3000 0 2000])

% Create xlabel
xlabel({'salaire mensuel net imposable (en euros)'});

% Create ylabel
ylabel({'imp�t sur le revenu annuel (en euros)'});

% Create title
title({'COMPARAISON DES IMPOTS ENTRE 2014 et 2015'});

% Create legend
legend1 = legend(' impot personne valide 2015',' impot personne valide 2014', ' impot personne invalide 2015', ' impot personne invalide 2014');
set(legend1,...
    'Position',[0.225760477692654 0.795202418506835 0.282261153672826 0.0773978518852336]);

fig4 = figure('Color',[1 1 1]);
plot(salaires,12*(impots_valide_2014-impots_valide),'Color','b','LineWidth',2);
hold on;
plot(salaires,12*(impots_invalide_2014-impots_invalide),'Color','r','LineWidth',2);
axis([2150 2200 0 500])

[MV, IV] = max(12*(impots_valide_2014-impots_valide))
[MI, II] = max(12*(impots_invalide_2014-impots_invalide))
salaires(IV)
salaires(II)

% Create xlabel
xlabel({'salaire mensuel net imposable (en euros)'});

% Create ylabel
ylabel({'�conomie annuelle (en euros)'});

% Create title
title({'ECONOMIE ANNUELLE REALISEE ENTRE 2014 et 2015'});

% Create legend
legend1 = legend(' Diff�rence 2014-2015 (valide)',' Diff�rence 2014-2015 (invalide)');
set(legend1,...
    'Position',[0.225760477692654 0.795202418506835 0.282261153672826 0.0773978518852336]);
